﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for FeePaymentList
/// </summary>

public class FeePaymentList
{
    public decimal Balance { get; set; }
    public string Class { get; set; }
    public string Deposit_Date { get; set; }
    public string Father_Name { get; set; }
    public int Installment { get; set; }
    public string Mother_Name { get; set; }
    public string Name { get; set; }
    public decimal Payment { get; set; }
    public string Remarks { get; set; }
    public int Roll_No_ { get; set; }
    public string Section { get; set; }
    public string Sem_Annual { get; set; }
    public string Session { get; set; }
}